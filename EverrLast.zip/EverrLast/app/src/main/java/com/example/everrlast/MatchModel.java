package com.example.everrlast;

public class MatchModel {
    private String name;
    private String image;
    private String UID;
    private String Age;
    private String UniversityOrSchool;
    private String DegreeOrProfession;

    public MatchModel(String name, String image_url, String unique_identifier, String age, String rgpv) {
        this.name = name;
        this.image = image;
        this.UID = UID;
        Age = age;

    }


    public String getUniversityOrSchool() {
        return UniversityOrSchool;
    }

    public void setUniversityOrSchool(String universityOrSchool) {
        UniversityOrSchool = universityOrSchool;
    }

    public String getDegreeOrProfession() {
        return DegreeOrProfession;
    }

    public void setDegreeOrProfession(String degreeOrProfession) {
        DegreeOrProfession = degreeOrProfession;
    }



    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getAge() {
        return Age;
    }

    public void setAge(String age) {
        Age = age;
    }
}
